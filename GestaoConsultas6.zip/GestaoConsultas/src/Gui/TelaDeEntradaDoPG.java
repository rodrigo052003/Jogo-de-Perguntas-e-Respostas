// Arquivo: TelaDeEntradaDoPG.java
// Pacote: Gui

package Gui;

import Consulta.*;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class TelaDeEntradaDoPG extends JFrame {
    private ControladorConsulta controlador;
    private JTextArea areaTexto;

    public TelaDeEntradaDoPG(ControladorConsulta controlador) {
        this.controlador = controlador;
        setTitle("Sistema de Consultas");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel painel = new JPanel(new GridLayout(8, 1, 5, 5)); // aumentei para 8 linhas
        JButton btnAgendar = new JButton("Agendar Consulta");
        JButton btnCancelar = new JButton("Cancelar Consulta");
        JButton btnAtualizar = new JButton("Atualizar Agenda");
        JButton btnRelatorio = new JButton("Gerar Relatórios");
        JButton btnCarregar = new JButton("Carregar Agenda");  // novo botão
        JButton btnSalvar = new JButton("Salvar Agenda");      // opcional
        areaTexto = new JTextArea();
        areaTexto.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaTexto);

        painel.add(btnAgendar);
        painel.add(btnCancelar);
        painel.add(btnAtualizar);
        painel.add(btnRelatorio);
        painel.add(btnCarregar);  // botão de carregar agenda
        painel.add(btnSalvar);    // botão de salvar agenda

        add(painel, BorderLayout.WEST);
        add(scroll, BorderLayout.CENTER);

        btnAgendar.addActionListener(e -> agendarConsulta());
        btnCancelar.addActionListener(e -> cancelarConsulta());
        btnAtualizar.addActionListener(e -> atualizarAgenda());
        btnRelatorio.addActionListener(e -> gerarRelatorios());
        btnCarregar.addActionListener(e -> carregarAgenda());
        btnSalvar.addActionListener(e -> salvarAgenda()); // opcional

        setVisible(true);
    }

    private void agendarConsulta() {
        String nomePaciente = JOptionPane.showInputDialog(this, "Nome do Paciente:");
        String cpfPaciente = JOptionPane.showInputDialog(this, "CPF do Paciente:");
        String nomeMedico = JOptionPane.showInputDialog(this, "Nome do Médico:");
        String cpfMedico = JOptionPane.showInputDialog(this, "CPF do Médico:");
        String especialidade = JOptionPane.showInputDialog(this, "Especialidade do Médico:");
        String dataHora = JOptionPane.showInputDialog(this, "Data e Hora da Consulta:");

        Paciente paciente = new Paciente(nomePaciente, cpfPaciente);
        Medico medico = new Medico(nomeMedico, cpfMedico, especialidade);
        Consulta consulta = new Consulta(paciente, medico, dataHora);

        controlador.adicionarPaciente(paciente);
        controlador.adicionarMedico(medico);
        controlador.agendarConsulta(consulta);

        JOptionPane.showMessageDialog(this, "Consulta agendada com sucesso!");
        atualizarAgenda();
    }

    private void cancelarConsulta() {
        String cpf = JOptionPane.showInputDialog(this, "Informe o CPF do paciente para cancelar a consulta:");
        boolean cancelada = controlador.cancelarConsulta(cpf);
        if (cancelada) {
            JOptionPane.showMessageDialog(this, "Consulta cancelada.");
        } else {
            JOptionPane.showMessageDialog(this, "Nenhuma consulta encontrada para o CPF informado.");
        }
        atualizarAgenda();
    }

    private void atualizarAgenda() {
        StringBuilder sb = new StringBuilder("Consultas Agendadas:\n\n");
        ArrayList<Consulta> consultas = controlador.getConsultas();
        for (Consulta c : consultas) {
            sb.append("Paciente: ").append(c.getPaciente().getNome())
              .append(" (").append(c.getPaciente().getCpf()).append(")\n")
              .append("Médico: ").append(c.getMedico().getNome())
              .append(" (").append(c.getMedico().getEspecialidade()).append(")\n")
              .append("Data/Hora: ").append(c.getDataHora()).append("\n\n");
        }
        areaTexto.setText(sb.toString());
    }

    private void gerarRelatorios() {
        try {
            RelatorioPDF.gerarRelatorioConsultas(controlador.getConsultas());
            RelatorioPDF.gerarRelatorioMedicos(controlador.getMedicos());
            RelatorioPDF.gerarRelatorioPacientes(controlador.getPacientes());
            JOptionPane.showMessageDialog(this, "Relatórios gerados com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao gerar relatórios: " + e.getMessage());
        }
    }

    private void carregarAgenda() {
        try {
            controlador.carregarMedicosCSV("medicos.csv");
            controlador.carregarPacientesCSV("pacientes.csv");
            controlador.carregarConsultasCSV("consultas.csv");
            JOptionPane.showMessageDialog(this, "Agenda carregada com sucesso!");
            atualizarAgenda();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar agenda: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void salvarAgenda() {
        try {
            controlador.salvarMedicosCSV("medicos.csv");
            controlador.salvarPacientesCSV("pacientes.csv");
            controlador.salvarConsultasCSV("consultas.csv");
            JOptionPane.showMessageDialog(this, "Agenda salva com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar agenda: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
