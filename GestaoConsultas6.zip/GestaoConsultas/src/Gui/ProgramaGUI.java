// Arquivo: ProgramaGUI.java
// Pacote: Gui

package Gui;

import Consulta.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProgramaGUI {
    private static ControladorConsulta controlador = new ControladorConsulta();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaDeEntradaDoPG(controlador);
        });
    }
}
