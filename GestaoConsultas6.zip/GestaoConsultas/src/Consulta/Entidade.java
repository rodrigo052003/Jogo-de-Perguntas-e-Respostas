// Arquivo: Entidade.java
// Pacote: Consulta

package Consulta;

public interface Entidade {
    public String getIdentificador();
}
