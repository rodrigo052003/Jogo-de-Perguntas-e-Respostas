// Arquivo: ControladorConsulta.java
// Pacote: Consulta

package Consulta;

import java.io.*;
import java.util.ArrayList;

public class ControladorConsulta {
    private ArrayList<Medico> medicos = new ArrayList<>();
    private ArrayList<Paciente> pacientes = new ArrayList<>();
    private ArrayList<Consulta> consultas = new ArrayList<>();

    public void adicionarMedico(Medico m) {
        medicos.add(m);
    }

    public void adicionarPaciente(Paciente p) {
        pacientes.add(p);
    }

    public void agendarConsulta(Consulta c) {
        consultas.add(c);
    }

    public boolean cancelarConsulta(String cpfPaciente) {
        for (Consulta c : consultas) {
            if (c.getPaciente().getCpf().equals(cpfPaciente)) {
                consultas.remove(c);
                return true;
            }
        }
        return false;
    }

    public ArrayList<Consulta> getConsultas() {
        return consultas;
    }

    public ArrayList<Medico> getMedicos() {
        return medicos;
    }

    public ArrayList<Paciente> getPacientes() {
        return pacientes;
    }

    public void limparConsultas() {
        consultas.clear();
    }
    
    public void limparMedicos() {
        medicos.clear();
    }
    
    public void limparPacientes() {
        pacientes.clear();
    }

    // --- Métodos para salvar dados em CSV ---

    public void salvarMedicosCSV(String caminho) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(caminho))) {
            for (Medico m : medicos) {
                // nome;cpf;especialidade
                bw.write(m.getNome() + ";" + m.getCpf() + ";" + m.getEspecialidade());
                bw.newLine();
            }
        }
    }

    public void salvarPacientesCSV(String caminho) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(caminho))) {
            for (Paciente p : pacientes) {
                // nome;cpf
                bw.write(p.getNome() + ";" + p.getCpf());
                bw.newLine();
            }
        }
    }

    public void salvarConsultasCSV(String caminho) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(caminho))) {
            for (Consulta c : consultas) {
                // cpfPaciente;cpfMedico;dataHora
                bw.write(c.getPaciente().getCpf() + ";" + c.getMedico().getCpf() + ";" + c.getDataHora());
                bw.newLine();
            }
        }
    }

    // --- Métodos para carregar dados de CSV ---
    
    public void carregarMedicosCSV(String caminho) throws IOException {
        medicos.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] campos = linha.split(";");
                if (campos.length == 3) {
                    Medico m = new Medico(campos[0], campos[1], campos[2]);
                    medicos.add(m);
                }
            }
        }
    }

    public void carregarPacientesCSV(String caminho) throws IOException {
        pacientes.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] campos = linha.split(";");
                if (campos.length == 2) {
                    Paciente p = new Paciente(campos[0], campos[1]);
                    pacientes.add(p);
                }
            }
        }
    }

    public void carregarConsultasCSV(String caminho) throws IOException {
        consultas.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] campos = linha.split(";");
                if (campos.length == 3) {
                    String cpfPaciente = campos[0];
                    String cpfMedico = campos[1];
                    String dataHora = campos[2];
                    // Encontrar paciente e médico pelos CPFs
                    Paciente paciente = null;
                    Medico medico = null;

                    for (Paciente p : pacientes) {
                        if (p.getCpf().equals(cpfPaciente)) {
                            paciente = p;
                            break;
                        }
                    }
                    for (Medico m : medicos) {
                        if (m.getCpf().equals(cpfMedico)) {
                            medico = m;
                            break;
                        }
                    }

                    if (paciente != null && medico != null) {
                        Consulta consulta = new Consulta(paciente, medico, dataHora);
                        consultas.add(consulta);
                    }
                    // Caso paciente ou médico não encontrados, pode optar por ignorar ou lançar exceção
                }
            }
        }
    }
}
