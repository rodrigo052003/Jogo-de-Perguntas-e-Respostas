// Arquivo: RelatorioPDF.java
// Pacote: Consulta

package Consulta;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class RelatorioPDF {

    public static void gerarRelatorioConsultas(ArrayList<Consulta> consultas) {
        try {
            Document doc = new Document();
            String caminho = "RelatorioConsultas.pdf";
            PdfWriter.getInstance(doc, new FileOutputStream(caminho));
            doc.open();
            doc.add(new Paragraph("Relatório de Consultas Agendadas\n\n"));

            for (Consulta c : consultas) {
                doc.add(new Paragraph("Paciente: " + c.getPaciente().getNome() +
                        " | CPF: " + c.getPaciente().getCpf() +
                        " | Médico: " + c.getMedico().getNome() +
                        " | Especialidade: " + c.getMedico().getEspecialidade() +
                        " | Data/Hora: " + c.getDataHora()));
                doc.add(new Paragraph("----------------------------------------------------------"));
            }

            doc.close();
            abrirPDF(caminho);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void gerarRelatorioMedicos(ArrayList<Medico> medicos) {
        try {
            Document doc = new Document();
            String caminho = "RelatorioMedicos.pdf";
            PdfWriter.getInstance(doc, new FileOutputStream(caminho));
            doc.open();
            doc.add(new Paragraph("Relatório de Médicos\n\n"));

            for (Medico m : medicos) {
                doc.add(new Paragraph("Nome: " + m.getNome() +
                        " | CPF: " + m.getCpf() +
                        " | Especialidade: " + m.getEspecialidade()));
                doc.add(new Paragraph("----------------------------------------------------------"));
            }

            doc.close();
            abrirPDF(caminho);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void gerarRelatorioPacientes(ArrayList<Paciente> pacientes) {
        try {
            Document doc = new Document();
            String caminho = "RelatorioPacientes.pdf";
            PdfWriter.getInstance(doc, new FileOutputStream(caminho));
            doc.open();
            doc.add(new Paragraph("Relatório de Pacientes\n\n"));

            for (Paciente p : pacientes) {
                doc.add(new Paragraph("Nome: " + p.getNome() +
                        " | CPF: " + p.getCpf()));
                doc.add(new Paragraph("----------------------------------------------------------"));
            }

            doc.close();
            abrirPDF(caminho);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para abrir o PDF automaticamente
    private static void abrirPDF(String caminho) {
        try {
            File arquivo = new File(caminho);
            if (arquivo.exists() && Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(arquivo);
            } else {
                System.out.println("Não foi possível abrir o arquivo PDF: " + caminho);
            }
        } catch (Exception e) {
            System.out.println("Erro ao tentar abrir o PDF: " + caminho);
            e.printStackTrace();
        }
    }
}
