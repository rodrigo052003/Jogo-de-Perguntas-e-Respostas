package Consulta;

public interface ICadastravel {
    public String getIdentificacao();
}
