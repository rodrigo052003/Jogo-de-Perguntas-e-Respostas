package Consulta;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

public class Notificacoes {

    private static final Pattern CPF_PATTERN = Pattern.compile("\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}");
    private static final SimpleDateFormat FORMATO_DATA = new SimpleDateFormat("dd/MM/yyyy");
    private static final SimpleDateFormat FORMATO_HORA = new SimpleDateFormat("HH:mm");

    static {
        FORMATO_DATA.setLenient(false);
        FORMATO_HORA.setLenient(false);
    }

    public static boolean cpfValido(String cpf) {
        return CPF_PATTERN.matcher(cpf).matches();
    }

    public static boolean cpfDuplicado(String cpfPaciente, String cpfMedico) {
        return cpfPaciente != null && cpfPaciente.equals(cpfMedico);
    }

    public static boolean dataValida(String data) {
        try {
            Date dataConsulta = FORMATO_DATA.parse(data);
            Date hoje = new Date();
            return !dataConsulta.before(hoje);
        } catch (ParseException e) {
            return false;
        }
    }

    public static boolean horaValida(String hora) {
        try {
            FORMATO_HORA.parse(hora);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public static String validarDados(String cpfPaciente, String cpfMedico, String data, String hora) {
        if (!cpfValido(cpfPaciente)) {
            return "CPF do paciente inválido! Use o formato xxx.sss.yyy-kk.";
        }
        if (!cpfValido(cpfMedico)) {
            return "CPF do médico inválido! Use o formato xxx.sss.yyy-kk.";
        }
        if (cpfDuplicado(cpfPaciente, cpfMedico)) {
            return "Paciente e médico não podem ter o mesmo CPF.";
        }
        if (!dataValida(data)) {
            return "Data inválida! Use o formato dd/mm/aaaa e não escolha datas passadas.";
        }
        if (!horaValida(hora)) {
            return "Hora inválida! Use o formato HH:mm.";
        }
        return null; // Dados válidos
    }
}
