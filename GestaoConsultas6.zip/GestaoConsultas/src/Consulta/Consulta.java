// Arquivo: Consulta.java
// Pacote: Consulta

package Consulta;

import java.io.Serializable;

public class Consulta implements Serializable {
    private Paciente paciente;
    private Medico medico;
    private String dataHora;

    public Consulta(Paciente paciente, Medico medico, String dataHora) {
        this.paciente = paciente;
        this.medico = medico;
        this.dataHora = dataHora;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public Medico getMedico() {
        return medico;
    }

    public String getDataHora() {
        return dataHora;
    }

    @Override
    public String toString() {
        return "Consulta: " + paciente + " com " + medico + " em " + dataHora;
    }
}
