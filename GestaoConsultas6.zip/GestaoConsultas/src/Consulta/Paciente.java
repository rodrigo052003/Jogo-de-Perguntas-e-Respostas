package Consulta;

public class Paciente extends Pessoa implements ICadastravel {

    private String convenio;

    public Paciente(String nome, String cpf) {
        super(nome, cpf);
        this.convenio = convenio;
    }

    public String getConvenio() {
        return convenio;
    }

    public void setConvenio(String convenio) {
        this.convenio = convenio;
    }

    @Override
    public String toString() {
        return "Paciente: " + getNome() + ", CPF: " + getCpf() + ", Convênio: " + convenio;
    }

    @Override
    public String getIdentificacao() {
        return this.getNome(); // Retorna nome como identificação
    }
}
